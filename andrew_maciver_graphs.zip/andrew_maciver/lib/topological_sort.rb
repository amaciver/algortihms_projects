require_relative 'graph'

# Implementing topological sort using both Khan's and Tarian's algorithms

def topological_sort(vertices)
  sorted = []
  q = []
  vertices.each do |vertex|
    if vertex.in_edges.empty?
      q.push(vertex)
    end
  end
  until q.empty?
    curr = q.shift
    sorted << curr
    edges = curr.out_edges.dup
    edges.each do |edge|
      if edge.to_vertex.in_edges.count <= 1
        q.push(edge.to_vertex)
      end
      edge.destroy!
    end
  end
  sorted
end
