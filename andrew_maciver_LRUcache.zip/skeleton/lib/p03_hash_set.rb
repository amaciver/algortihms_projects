require_relative 'p02_hashing'

class HashSet
  attr_reader :count

  def initialize(num_buckets = 8)
    @store = Array.new(num_buckets) { Array.new }
    @count = 0
  end

  def insert(key)
    num = key.hash
    unless include?(num)
      self[num].push(num)
      @count += 1
    end
    resize! if @count == num_buckets
  end

  def include?(key)
    num = key.hash
    self[num].include?(num)
  end

  def remove(key)
    if include?(key)
      num = key.hash
      self[num].delete(num)
      @count -= 1
    end
  end

  private

  def [](num)
    @store[num % num_buckets]
    # optional but useful; return the bucket corresponding to `num`
  end

  def num_buckets
    @store.length
  end

  def resize!
    new_store = ( Array.new(num_buckets * 2) { Array.new } )
    @store.each do |bucket|
      bucket.each do |el|
        new_store[el % (num_buckets * 2)] << el
      end
    end
    @store = new_store
  end
end
