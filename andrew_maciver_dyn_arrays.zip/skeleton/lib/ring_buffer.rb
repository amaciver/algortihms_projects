require_relative "static_array"

class RingBuffer
  attr_reader :length
  attr_reader :capacity
  attr_reader :store

  def initialize(initial = 8)
    @store = StaticArray.new(initial)
    @length = 0
    @start_idx = 0
    @capacity = @store.length
  end

  # O(1)
  def [](index)
    if index >= @length
      raise 'index out of bounds'
    end
    @store[(index+@start_idx) % @store.length]
  end

  # O(1)
  def []=(index, value)
    resize! if index >= @store.length
    @store[(index+@start_idx) % @store.length] = value
  end

  # O(1)
  def pop
    raise 'index out of bounds' if self[0] == nil
    result = self[@length-1]
    self[@length-1] = nil
    @length -= 1
    result
  end

  # O(1) ammortized
  def push(val)
    resize! if @length >= @store.length
    self[@length] = val
    @length += 1
  end

  # O(1)
  def shift
    result = self[0]
    # self[0] = nil
    @start_idx += 1
    @start_idx = @start_idx % @store.length
    @length -= 1
    result
  end

  # O(1) ammortized
  def unshift(val)
    @length += 1
    resize! if @length >= @store.length
    @start_idx = (@start_idx-1) % @store.length
    self[0] = val
    # @store[@start_idx] = val
  end

  def check_index(index)
  end

  def resize!
    new_array = StaticArray.new(@store.length.zero? ? 8 : @store.length * 2)
    i = 0
    while i < @length
      new_array[i] = @store[(@start_idx + i) % @store.length]
      i += 1
    end
    @start_idx = 0
    @store = new_array
    @capacity = @store.length
  end
end
