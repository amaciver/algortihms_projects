require_relative "static_array"

class DynamicArray

  attr_reader :length
  attr_accessor :capacity, :store
  attr_writer :length

  def initialize(initial = 8)
    @store = StaticArray.new(initial)
    @length = 0
  end

  # O(1)
  def [](index)
    if index >= @length
      raise 'index out of bounds'
    end
    @store[index]
  end

  # O(1)
  def []=(index, value)
    resize! if index >= @store.length
    @store[index] = value
  end

  # O(1)
  def pop
    raise 'index out of bounds' if self[0] == nil
    result = self[@length-1]
    self[@length-1] = nil
    @length -= 1
    result
  end

  # O(1) ammortized; O(n) worst case. Variable because of the possible
  # resize.
  def push(val)
    resize! if @length >= @store.length
    self[@length] = val
    @length += 1
  end

  # O(n): has to shift over all the elements.
  def shift
    result = self[0]
    shifted_array = StaticArray.new(@store.length)
    i = 1
    while i < @length
      shifted_array[i-1] = self[i]
      i += 1
    end
    @length -= 1
    @store = shifted_array
    result
  end

  # O(n): has to shift over all the elements.
  def unshift(val)
    @length += 1
    resize! if @length >= @store.length-1
    unshifted_array = StaticArray.new(@store.length)
    i = 1
    unshifted_array[0] = val
    while i < @length
      unshifted_array[i] = self[i-1]
      i += 1
    end
    @store = unshifted_array
  end


  def first
  end

  def last
  end

  def capacity
    @store.length
  end

  def each(&prc)
    i = 0
    while i < @store.length
      prc.call(@store[i])
      i += 1
    end
    @store
  end
 
  def ==(other)
    return false unless [Array, DynamicArray].include?(other.class)
    # ...
  end


  def include?(val)
    self.each do |el|
      return true if el == val
    end
    return false
  end

  alias_method :<<, :push
  [:length, :size].each { |method| alias_method method, :length }


  def check_index(index)
  end

  # O(n): has to copy over all the elements to the new store.
  def resize!
    new_array = StaticArray.new(@store.length.zero? ? 8 : @store.length * 2)
    puts new_array.length
    i = 0
    while i < @store.length
      new_array[i] = @store[i]
      i += 1
    end
    @store = new_array
  end
end
