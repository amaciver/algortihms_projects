require_relative 'bst_node.rb'

class BinarySearchTree
  attr_accessor :root

  def initialize
    @root = BSTNode.new()

  end

  def find(val, root = self.root)
    return true if root.val == val
    if val <= root.val
      return false if root.left.nil?
      find(val, root.left)
    else
      return false if root.right.nil?
      find(val, root.right)
    end
  end

  def insert(val, root = self.root)
    if root.val.nil?
      @root.val = val
      return
    end
    if val <= root.val
      if root.left.nil?
        root.left = BSTNode.new(val)
        root.left.parent = root
        return
      else
        insert(val, root.left)
      end
    else
      if root.right.nil?
        root.right = BSTNode.new(val)
        root.right.parent = root
        return
      else
        insert(val, root.right)
      end
    end
  end

  def delete(val, root = self.root)
    if root.val == val
      if root.left
        swap = maximum(root.left)
        swap.parent.right = nil #unhook swap from parent
        swap.parent = nil #reset swap parent
        if root.parent
          swap.parent = root.parent #connect swap to root's parent
          swap.parent.left = swap if root.parent.left == root #connect root's parent to swap
          swap.parent.right = swap if root.parent.right == root
        end
        swap.left = root.left #connect swap to left
        root.left.parent = swap #hook up left to swap
        root.left = nil #unhook root from left
        swap.right = root.right #connect swap to right
        root.right.parent = swap #hook up right to swap
        root.right = nil #unhook root from right
      elsif root.right
        root.right.parent = root.parent
        root.parent.right = root.right if root.parent.right == root
        root.parent.left = root.right if root.parent.left == root
        root.parent = nil
        root.right = nil
      else
        root.parent.right = nil if root.parent.right == root
        root.parent.left = nil if root.parent.left == root
        root.parent = nil
      end
    elsif val <= root.val
      return false if root.left.nil?
      delete(val, root.left)
    else
      return false if root.right.nil?
      delete(val, root.right)
    end
    true
  end

  def is_balanced?
    return true if (depth(root.left)-depth(root.right)).abs <= 1
    false
  end

  def in_order_traversal(root = self.root)
    return [root.val] if root.left.nil? && root.right.nil?
    results = []
    results.concat(in_order_traversal(root.left)) if root.left
    results.push(root.val)
    results.concat(in_order_traversal(root.right)) if root.right
    results
  end

  def maximum(el)
    return el if node.right.nil?
    node = el
    until node.right.nil?
      node = node.right
    end
    node
  end

  def depth(root = self.root)
    return nil if root.nil?
    if root.left.nil? && root.right.nil?
      return 0
    end
    depth_left = root.left ? depth(root.left) + 1 : 0
    depth_right = root.right ? depth(root.right) + 1 : 0
    [depth_left, depth_right].max
  end
end

# b = BinarySearchTree.new()
# [8,2,10].each { |el| b.insert(el) }
