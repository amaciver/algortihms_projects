class BSTNode

  attr_accessor :left, :right, :parent, :val

  def initialize(val = nil)
    @left = nil
    @right = nil
    @val = val
    @parent = nil
  end
end
