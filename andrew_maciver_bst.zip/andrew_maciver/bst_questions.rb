# *NB*: what do you need to require here? This is a good chance to review a little Ruby require syntax.
require_relative "binary_search_tree.rb"
require_relative "bst_node.rb"


def kth_largest(bst, k)
  bst.in_order_traversal[-k]
end

def lowest_common_ancestor(node1, node2)
  depth1 = 0
  depth2 = 0
  parent1 = node1.parent
  parent2 = node2.parent
  until parent1.nil?
    depth1 += 1
    parent1 = parent1.parent
  end
  until parent2.nil?
    depth2 += 1
    parent2 = parent2.parent
  end
  parent1 = node1
  parent2 = node2
  if depth1 > depth2
    until depth1 == depth2
      parent1 = node1.parent
      depth1 -= 1
    end
  end
  if depth2 > depth1
    until depth1 == depth2
      parent2 = node2.parent
      depth2 -= 1
    end
  end
  until parent1 == parent2
    parent1, parent2 = parent1.parent, parent2.parent
  end
  parent1
end

def post_order_traversal(root = BSTNode.new)
  return [root.val] if root.left.nil? && root.right.nil?
  results = []
  results.concat(post_order_traversal(root.left)) if root.left
  results.concat(post_order_traversal(root.right)) if root.right
  results.push(root.val)
  results
end

def reconstruct(post_order, in_order)
end
